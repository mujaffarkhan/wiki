<?php

class UsersController extends Zend_Controller_Action
{

    /**
     * Application keys from appkeys.ini
     * 
     * @var Zend_Config 
     */
    protected $_keys;

    public function init()
    {
        $this->_keys = Zend_Registry::get('keys');
        $this->_helper->_layout->setLayout('anonymous');
    }

    public function indexAction()
    {
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
            $this->view->identity = $auth->getIdentity();
            $this->_redirect("/");
        } else {
            $this->_redirect("/users/login");
        }
        // action body
    }

    public function loginAction()
    {
        //$this->view->headScript()->appendFile('/js/main.js');
        //$this->_redirect("/");
        $return_url = '/';

        $form = $this->_getLoginForm();

        // get an instace of Zend_Auth
        $auth = Zend_Auth::getInstance();

        // check if a user is already logged
        if ($auth->hasIdentity()) {
            return $this->_redirect("/");
        }

        // $openid_mode will be set after first query to the openid provider
        $openid_mode = $this->getRequest()->getParam('openid_mode', null);

        // do the first query to an authentication provider
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost()) && $form->getValue('action') == "verify") {

            // Unset session which is used for FISystem
            Zend_Session::namespaceUnset('mysession');
            // Unset the SESSION lguser of remote login
            $_SESSION['lguser'] = array();

            $openid_identifier = 'https://www.google.com/accounts/o8/site-xrds?hd=southeastdrilling.com';
            // $openid_identifier = 'https://www.google.com/accounts/o8/id';
            $adapter = $this->_getOpenIdAdapter($openid_identifier);

            // specify what to grab from the provider and what extension to use
            // for this purpose
            $toFetch = $this->_keys->openid->tofetch->toArray();

            $ext = $this->_getOpenIdExt('ax', $toFetch);
            $adapter->setExtensions($ext);
            // here a user is redirect to the provider for loging
            $result = $auth->authenticate($adapter);

            // the following two lines should never be executed unless the redirection faild.
            $this->_helper->FlashMessenger('Redirection failed');
            return $this->_redirect('/');
        } else if ($openid_mode) {
            // for openid                
            $adapter = $this->_getOpenIdAdapter(null);

            // specify what to grab from the provider and what extension to use
            // for this purpose
            $ext = null;

            $toFetch = $this->_keys->openid->tofetch->toArray();

            // for google and yahoo use AtributeExchange Extension
            if (isset($_GET['openid_ns_ext1']) || isset($_GET['openid_ns_ax'])) {
                $ext = $this->_getOpenIdExt('ax', $toFetch);
            } else if (isset($_GET['openid_ns_sreg'])) {
                $ext = $this->_getOpenIdExt('sreg', $toFetch);
            }

            if ($ext) {
                $ext->parseResponse($_GET);
                $adapter->setExtensions($ext);
            }

            $result = $auth->authenticate($adapter);

            if ($result->isValid()) {
                $toStore = array('identity' => $auth->getIdentity());

                if ($ext) {
                    // for openId
                    $toStore['properties'] = $ext->getProperties();
                }

                $auth->getStorage()->write($toStore);
                if ($_SESSION["refUrl"] != '') {
                    $return_url = $_SESSION["refUrl"];
                    $_SESSION["refUrl"] = "";
                    return $this->_redirect($return_url);
                } else {
                    return $this->_redirect('/');
                }
            } else {
                // Zend_Debug::dump($result);
                $auth->clearIdentity();
                $this->_helper->FlashMessenger('Login failed. Please try again.');
                $this->_helper->FlashMessenger($result->getMessages());
                return $this->_redirect('/users/login');
            }
        }
        $this->view->form = $form;
    }

    public function mbloginAction()
    {
        $return_url = '/';
        $this->view->hasIdentity = false;
        $form = $this->_getLoginForm();

        // get an instace of Zend_Auth
        $auth = Zend_Auth::getInstance();

        // check if a user is already logged
        if ($auth->hasIdentity()) {
            $this->view->hasIdentity = false;
        }

        // $openid_mode will be set after first query to the openid provider
        $openid_mode = $this->getRequest()->getParam('openid_mode', null);

        // do the first query to an authentication provider
        if ($this->getRequest()->isPost() && $form->isValid($this->getRequest()->getPost()) && $form->getValue('action') == "verify") {

            // Unset session which is used for FISystem
            Zend_Session::namespaceUnset('mysession');
            // Unset the SESSION lguser of remote login
            $_SESSION['lguser'] = array();

            $openid_identifier = 'https://www.google.com/accounts/o8/site-xrds?hd=southeastdrilling.com';
            // $openid_identifier = 'https://www.google.com/accounts/o8/id';
            $adapter = $this->_getOpenIdAdapter($openid_identifier);

            // specify what to grab from the provider and what extension to use
            // for this purpose
            $toFetch = $this->_keys->openid->tofetch->toArray();

            $ext = $this->_getOpenIdExt('ax', $toFetch);
            $adapter->setExtensions($ext);
            // here a user is redirect to the provider for loging
            $result = $auth->authenticate($adapter);

            // the following two lines should never be executed unless the redirection faild.
            $this->_helper->FlashMessenger('Redirection failed');

            return $this->_redirect('/');
        } else if ($openid_mode) {
            // for openid                
            $adapter = $this->_getOpenIdAdapter(null);

            // specify what to grab from the provider and what extension to use
            // for this purpose
            $ext = null;

            $toFetch = $this->_keys->openid->tofetch->toArray();

            // for google and yahoo use AtributeExchange Extension
            if (isset($_GET['openid_ns_ext1']) || isset($_GET['openid_ns_ax'])) {
                $ext = $this->_getOpenIdExt('ax', $toFetch);
            } else if (isset($_GET['openid_ns_sreg'])) {
                $ext = $this->_getOpenIdExt('sreg', $toFetch);
            }

            if ($ext) {
                $ext->parseResponse($_GET);
                $adapter->setExtensions($ext);
            }

            $result = $auth->authenticate($adapter);

            if ($result->isValid()) {
                $toStore = array('identity' => $auth->getIdentity());

                if ($ext) {
                    // for openId
                    $toStore['properties'] = $ext->getProperties();
                }

                $auth->getStorage()->write($toStore);
                if ($_SESSION["refUrl"] != '') {
                    $return_url = $_SESSION["refUrl"];
                    $_SESSION["refUrl"] = "";
                    return $this->_redirect($return_url);
                } else {
                    $identity = Smapp::getCurrentUser();
                    $name = str_replace(' ', '_', $identity->name);
                    //echo $identity->id." ".$name;exit;
                    return $this->_redirect('/users/loginsuccess?id=' . $identity->id . '&name=' . $name . '&logedin=success&rd=');
                }
            } else {
                // Zend_Debug::dump($result);
                $auth->clearIdentity();
                return $this->_redirect('/users/mblogin');
            }
        }
        $this->view->form = $form;
    }

    public function loginsuccessAction()
    {
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }

    public function logoutAction()
    {
        $auth = Zend_Auth::getInstance();
        $auth->clearIdentity();
        $this->_helper->FlashMessenger('You were logged out');
        return $this->_redirect('/users/login');
    }

    protected function _getOpenIdAdapter($openid_identifier = null)
    {
        $adapter = new Zend_Auth_Adapter_OpenId($openid_identifier);
        $dir = "/tmp";

        if (!file_exists($dir)) {
            if (!mkdir($dir)) {
                throw new Zend_Exception("Cannot create $dir to store tmp auth data.");
            }
        }

        $adapter->setStorage(new Zend_OpenId_Consumer_Storage_File($dir));

        return $adapter;
    }

    private function _getLoginForm()
    {
        $form = new Zend_Form();


        return $form->setMethod("post")
                ->setOptions(array("class" => "form"))
                ->addElement($form->createElement("hidden", "action")->setValue('verify'))
                ->addElement($form->createElement("submit", "Login")->setOptions(array("class" => "btn btn-primary")));
    }

    protected function _getOpenIdExt($extType, array $propertiesToRequest)
    {

        $ext = null;

        if ('ax' == $extType) {
            $ext = new My_OpenId_Extension_AttributeExchange($propertiesToRequest);
        } elseif ('sreg' == $extType) {
            $ext = new Zend_OpenId_Extension_Sreg($propertiesToRequest);
        }

        return $ext;
    }

    /**
     * Manage user action to 
     * This methods runs prior executings any action to initialize variables
     * 
     * @author Mujaffar added on 14 Aug 2012
     */
    public function manageuserAction()
    {
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
            $this->view->activepage = "manageuser";
            /* Initialize action controller here */
            $this->_helper->_layout->setLayout('dashboard');
            $this->_identity = Smapp::getCurrentUser();
            $user = Application_Model_User::Mapper()->find($this->_identity->id);

            if (is_null($user))
                throw new Exception("User Not Found");

            // $form = $this->getForm($user);
            $form = new Admin_Form_AddUser($user);

            $editArray = $user->get('id,name,email,role_id,sendto_list');

            if ($this->getRequest()->isPost()) {
                $this->view->post = true;
                // Get foreman Id by using User Email address
                $foremanRowset = Application_Model_Foreman::mapper()->getforemandetails('email', $user->email);
                if (sizeof($foremanRowset) > 0) {
                    // Foreman record is already present 
                    $foreman = Application_Model_Foreman::Mapper()->find($foremanRowset->id);
                }
                $formdata = $this->getRequest()->getPost();

                if ($form->isValid($formdata)) {
                    $raw_list = nl2br($form->getValue("sendto_list"));
                    $raw_list = str_replace(",", " ", $raw_list);
                    $raw_list = str_replace(";", " ", $raw_list);
                    foreach (preg_split('/ /', $raw_list) as $token) {
                        // Replace last two characters if they are br
                        if (substr($token, -2) == "br")
                            $token = substr($token, 0, -2);
                        $email = filter_var(filter_var($token, FILTER_SANITIZE_EMAIL), FILTER_VALIDATE_EMAIL);
                        if ($email !== false) {
                            $emails[] = $email;
                        }
                    }
                    $sendto_list = '';
                    foreach ($emails AS $rowEmail) {
                        if ($sendto_list != '')
                            $sendto_list .= ", ";
                        $sendto_list .= $rowEmail;
                    }
                    $foreman->setSendto_list($sendto_list);
                    $foreman->save();
                    $editArray['sendto_list'] = $sendto_list;
                    $this->view->updated = true;
                }
            } else {
                $foremanRowset = '';
                if ($user->role_id != 2) {
                    return $this->_forward('error', 'fisystem', 'default', array('from' => 'fisystem',
                            'header' => 'Access Denied', 'message' => 'Only foreman account can access this page!'));
                }
                if ($user->role_id == 2) {
                    $foremanRowset = Application_Model_Foreman::mapper()->getforemandetails('email', $editArray['email']);
                    $foremanRowset->sendto_list;
                    if (sizeof($foremanRowset) > 0)
                        $editArray['sendto_list'] = $foremanRowset->sendto_list;
                }
                else {
                    $form->removeElement('sendto_list');
                }
            }
            $form->populate($editArray);

            $this->view->form = $form;

            $this->view->user = $user;
        } else {
            $this->_redirect('/');
        }
    }

    /**
     * Method to Change login session of User
     * 
     * @author  Mujaffar Sanadi     Created on: 06 July 2013
     */
    public function switchLoginAction()
    {
        $identity = Smapp::getOriginalUser();

        $this->view->activepage = 'switch-login';
        /* Initialize action controller here */
        $this->_helper->_layout->setLayout('dashboard');
        $this->view->identity = Smapp::getCurrentUser();
        $this->view->orgIdentity = Smapp::getOriginalUser();
        
        if ($identity['role_id'] == 1) {
            $this->view->users = Application_Model_User::Mapper()->getActive();
        } else if ($identity['role_id'] == 3) {
            $supRecord = Application_Model_User::Mapper()->getSuperiDtls($identity['id']);
            
            // Get all active drills
            $superiDrills = Application_Model_Drill::Mapper()->getAllActiveForSuperintendent($supRecord[0]['superitendent_id']);
            $arrForemanIds = array();
            foreach ($superiDrills['regularDrills'] As $rowDrill) {
                if ($rowDrill['primary_foreman_id']) {
                    if (!in_array($rowDrill['primary_foreman_id'], $arrForemanIds)) {
                        $arrForemanIds[] = $rowDrill['primary_foreman_id'];
                    }
                }
                if ($rowDrill['secondary_foreman_id']) {
                    if (!in_array($rowDrill['secondary_foreman_id'], $arrForemanIds)) {
                        $arrForemanIds[] = $rowDrill['secondary_foreman_id'];
                    }
                }
            }
            foreach ($superiDrills['mobeDrills'] As $rowDrill) {
                if ($rowDrill['map_foreman_id']) {
                    if (!in_array($rowDrill['map_foreman_id'], $arrForemanIds)) {
                        $arrForemanIds[] = $rowDrill['map_foreman_id'];
                    }
                }
            }
            
            if (count($arrForemanIds)) {
                $this->view->users = Application_Model_User::Mapper()->getSelective($arrForemanIds);
            }
        }
        
        if ($this->getRequest()->isPost()) { 

            // Check whether user allowed to Switch-login for provided user email-address
            $allowedToChange = false;
            
            foreach ($this->view->users As $rowUser) {
                if ($rowUser->email == $this->getRequest()->getParam('sltUser')) {
                    $allowedToChange = true;
                }
            }
            
            if ($allowedToChange) { 
                $this->view->sltUser = $this->getRequest()->getParam('sltUser');
                $userDetail = Application_Model_User::Mapper()->findByEmail($this->getRequest()->getParam('sltUser'));
                if ($userDetail->role_id == 1) {
                    $_SESSION['lguser'] = array();
                } else {
                    // Check whether original login is of admin or superintendent then only change session
                    $identity = Smapp::getOriginalUser();
                    if ($identity['role_id'] == 1 || $identity['role_id'] == 3) {
                        if ($userDetail->id != '' && $userDetail->email != '' && $userDetail->role_id != '' && $userDetail->name != '') {
                            $_SESSION['lguser'] = array('name' => $userDetail->name, 'email' => $userDetail->email,
                                'role_id' => $userDetail->role_id, 'id' => $userDetail->id);
                        }
                    }
                }
            }
        }
    }

    /**
     * Method to unset Swith login session of User
     * 
     * @author  Mujaffar Sanadi     Created on: 06 July 2013
     */
    public function unsetSwitchLoginAction()
    {
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        $_SESSION['lguser'] = array();
    }

    public function uploadimageAction()
    {
        $loader = Zend_Loader_Autoloader::getInstance();
        $loader->registerNamespace('Polycast');

//        $filter = new Polycast_Filter_ImageSize();
//        $filter->getConfig()
//            ->setHeight(500)
//            ->setWidth(500);
//        $outputPath = $filter->filter('photo/5.gif');
//        header('Content-Type: image/jpeg');
//        $fh = fopen($outputPath, 'r');
//        fpassthru($fh);
//        fclose($fh);

        $filter = new Polycast_Filter_ImageSize();

        $filter->setOutputPathBuilder(
            new Polycast_Filter_ImageSize_PathBuilder_Standard('photo/thumbnails'));

        $filter->getConfig()
            ->setHeight(100)
            ->setWidth(200)
            ->setQuality(75)
            ->setOverwriteMode(Polycast_Filter_ImageSize::OVERWRITE_ALL)
            ->setOutputImageType(Polycast_Filter_ImageSize::TYPE_JPEG)
            ->setStrategy(new Polycast_Filter_ImageSize_Strategy_Crop());

        $output = $filter->filter('photo/1.jpg');

        header('Content-Type: image/jpeg');
        $fh = fopen($output, 'r');
        fpassthru($fh);
        fclose($fh);
    }

    public function mobileAction()
    {
        $postParams = $this->getRequest()->getParams();
        json_encode($postParams);
    }

}
