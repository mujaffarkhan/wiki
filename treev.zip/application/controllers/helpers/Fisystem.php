<?php

/**
 * Action helper class created to handle Progress report add Field input system functionality
 * 
 * @author  Mujaffar Sanad  Created on 01 July 2013     [Created getWeekDrill method to return worked drill details  for provided week range]
 * @author  Last Modified By : Mujaffar Sanadi On 06 Aug 2013   [Created checkForSuperiAccount method to check whether loged in user in Superintendent]
 * @author  Last Modified By : Mujaffar Sanadi on 04 Sep 2013   [Created Methods generateRandomNo and getSuperiForemans]
 * @author  Last Modified By : Mujaffar Sanadi on 24 Sep 2013   [Created Method getWorkingRig to get current working Rig id for Foreman]
 */
class Zend_Controller_Action_Helper_Fisystem extends Zend_Controller_Action_Helper_Abstract
{

    /**
     * Method to return worked drill details  for provided week range
     * 
     * @param date $startDate
     * @param date $endDate
     * @author Mujaffar Sanadi  Created on: 01 July 2013
     * @return array $drillIds
     */
    public function getWeekDrill($startDate, $endDate)
    {
        
    }

    /**
     * Method to check whether loged in user in Superintendent, If yes then fetch associated foreman and return
     * This is useful for FISystem (Superi adding Foreman's daily progress reports)
     * 
     * @param   Object $identity 
     * @author  Mujaffar Sanadi     Created on: 06 Aug 2013
     */
    public function checkForSuperiAccount($identity)
    {
        // Fetch superintendent Id by using user email address
        $superiDtls = Application_Model_Superintendent::Mapper()->getDetails('email', $identity->email);

        if (!$superiDtls) {
            return false;
        }

        // Get superintendent working current drill and Foreman id
        $drills = Application_Model_Drill::Mapper()->getSuperintendentDrills($superiDtls->id, 'all');

        $superiDrills = array();
        $superiForeman = array();
        // Check sizeof drills
        // If more than one drill present, Then extract related foreman and give option to select one of them
        foreach ($drills As $rowDrill) {
            $superiDrills[] = $rowDrill->id;
            // Check for drill Primary and Secondary foreman ids
            if ($rowDrill->primary_foreman_id != '' && $rowDrill->primary_foreman_id != 0) {
                if (!in_array($rowDrill->primary_foreman_id, $superiForeman)) {
                    $superiForeman[] = $rowDrill->primary_foreman_id;
                }
            }
            if ($rowDrill->secondary_foreman_id != '' && $rowDrill->secondary_foreman_id != 0) {
                if (!in_array($rowDrill->secondary_foreman_id, $superiForeman)) {
                    $superiForeman[] = $rowDrill->secondary_foreman_id;
                }
            }
        }
        return $returnArray = array('drills' => $superiDrills, 'superiForeman' => $superiForeman);
    }

    /**
     * Function to generate random number for creating session variable
     * 
     * @author  Mujaffar Sanadi     Created on: 04 Sep 2013
     * @return  String   $randNo 
     */
    public function generateRandomNo()
    {
        $randNo = rand();
        settype($randNo, "string");
        $randNo{rand(1, (strlen($randNo) - 1))} = 'm';
        return $randNo;
    }

    /**
     * Method to get Superintendent related Foreman's
     * 
     * @author  Mujaffar Sanadi     Created on: 04 Sep 2013
     * @param int $foremanId
     * @param Object $identity
     * @return array $superiForeman
     */
    public function getSuperiForemans($foremanId, $identity)
    {
        // Fetch superintendent Id by using user email address
        $superiDtls = Application_Model_Superintendent::Mapper()->getDetails('email', $identity->email);

        if (!$superiDtls) {
            return array('status' => 'error', 'msg' => 'SNF');
        }
        // Get superintendent working current drill and Foreman id
        $drills = Application_Model_Drill::Mapper()->getSuperintendentDrills($superiDtls->id, 'current');

        $superiForeman = array();
        // Check sizeof drills
        // If more than one drill present, Then extract related foreman and give option to select one of them
        foreach ($drills As $rowDrill) {
            // Check for drill Primary and Secondary foreman ids
            if ($rowDrill->primary_foreman_id != '' && $rowDrill->primary_foreman_id != 0) {
                $superiForeman[] = $rowDrill->primary_foreman_id;
                if ($foremanId == '') {
                    $foremanId = $rowDrill->primary_foreman_id;
                }
            }
            if ($rowDrill->secondary_foreman_id != '' && $rowDrill->secondary_foreman_id != 0) {
                $superiForeman[] = $rowDrill->secondary_foreman_id;
                if ($foremanId == '') {
                    $foremanId = $rowDrill->secondary_foreman_id;
                }
            }
        }

        if (sizeof($superiForeman) == 0) {
            return array('status' => 'error', 'msg' => 'NAF');
        }

        return array('status' => 'success', 'first' => $foremanId, 'list' => $superiForeman);
    }

    /**
     * Method to get current working Rig id for Foreman 
     * 
     * @author  Mujaffar Sanadi  Created on 23 Sep 2013
     * @param int $foremanId
     */
    public function getWorkingRig($foremanId = null, $rigId = null, $for = 'foreman')
    {
        if ($for == 'foreman') {
            $arrDrillRowset = Application_Model_Drill::Mapper()->getCurrentForForeman($foremanId);
            
            // Check for any Major Mobe drill assignment
            $drillMajorMobeList = Application_Model_MapMobeDrillForeman::Mapper()->getCurrent($foremanId, null);
            
            if (sizeof($drillMajorMobeList) > 0) {
                foreach ($drillMajorMobeList As $rowMobeDrill) {
                    $mobePhase = Application_Model_Phase::mapper()->find($rowMobeDrill['phase_id']);

                    if ($mobePhase->percentComplete() < 100 && sizeof($drillMajorMobe) == 0) {
                        $drillMajorMobe[0] = $rowMobeDrill;
                        $drillMajorMobe[0]['target_start_date'] = $drillMajorMobe[0]['map_target_start_date'];
                    }
                }
            }

            //$drills = Application_Model_Drill::Mapper()->getAllActiveForForeman($foremanId);
            //return $this->checkDrlPrecByForeman($drills);
        } elseif ($for == 'rig') {
            $arrDrillRowset = Application_Model_Drill::Mapper()->getCurrentForForeman(null, null, $rigId);
            // Check for any Major Mobe drill assignment
            $drillMajorMobe = Application_Model_MapMobeDrillForeman::Mapper()->getCurrent(null, $rigId);
        }

        $drillRowset = array();
        if (sizeof($arrDrillRowset) > 0 && sizeof($drillMajorMobe) == 0) {
            $drillRowset[] = $arrDrillRowset[0];
        } elseif (sizeof($arrDrillRowset) == 0 && sizeof($drillMajorMobe) > 0) {
            $drillRowset[] = Application_Model_Drill::Mapper()->find($drillMajorMobe[0]->drill_id);
            $drillRowset[0]->target_start_date = $drillMajorMobe[0]->target_start_date;
            $drillRowset[] = array('rigId' => $drillMajorMobe[0]->rig_id, 'phaseId' => $drillMajorMobe[0]->phase_id, 'rigName' => $drillMajorMobe[0]->rig_name);
        } elseif (sizeof($arrDrillRowset) > 0 && sizeof($drillMajorMobe) > 0) {
            if (strtotime($arrDrillRowset[0]->target_start_date) < strtotime($drillMajorMobe[0]->map_target_start_date)) {
                $drillRowset[] = $arrDrillRowset[0];
            } elseif (strtotime($arrDrillRowset[0]->target_start_date) > strtotime($drillMajorMobe[0]->map_target_start_date)) {
                $drillRowset[] = Application_Model_Drill::Mapper()->find($drillMajorMobe[0]->drill_id);
                $drillRowset[0]->target_start_date = $drillMajorMobe[0]->target_start_date;
                $drillRowset[] = array('rigId' => $drillMajorMobe[0]->rig_id, 'phaseId' => $drillMajorMobe[0]->phase_id, 'rigName' => $drillMajorMobe[0]->rig_name);
            } else {
                $drillRowset[] = Application_Model_Drill::Mapper()->find($drillMajorMobe[0]->drill_id);
                $drillRowset[0]->target_start_date = $drillMajorMobe[0]->target_start_date;
                $drillRowset[] = array('rigId' => $drillMajorMobe[0]->rig_id, 'phaseId' => $drillMajorMobe[0]->phase_id, 'rigName' => $drillMajorMobe[0]->rig_name);
            }
        }
        return $drillRowset;
    }

    /**
     * Helper method to make decision of Drill/Yard display in FISystem
     * 
     * @author  Mujaffar Sanadi Created on : 14 Jan 2013
     * @param array $params 
     */
    public function fisDrillYardDisplay($params)
    {
        if (isset($params['type'])) {
            if ($params['type'] == 'yard') {
                
            }
        }
        $drill = Application_Model_Drill::Mapper()->find($this->getRequest()->getParam('id'));
        if (!$drill) {
            return $this->_forward('error', 'fisystem', 'default', array('from' => 'fisystem',
                    'header' => 'Drill not found', 'message' => 'Provided drill not found in system!', 'identity' => $this->_identity->role_id));
        }

        if ($rowForeman != null || $this->_identity->role_id == 1 || $this->_identity->role_id == 3) :
            // If role Superintendent check for having access to drill
            if ($this->_identity->role_id == 3) {
                $this->view->superiDrillForeman = $this->_helper->Fisystem->checkForSuperiAccount($this->_identity);

                if (!$this->view->superiDrillForeman) {
                    return $this->_forward('error', 'fisystem', 'default', array('from' => 'fisystem',
                            'header' => 'Access denied', 'message' => 'Superintendent account not found', 'identity' => $identity->role_id));
                }

                if (!in_array($drill->id, $this->view->superiDrillForeman['drills'])) {
                    return $this->_forward('error', 'fisystem', 'default', array('from' => 'fisystem',
                            'header' => 'Access Denied', 'message' => 'You are not allowed to access this drill!', 'identity' => $this->_identity->role_id));
                }
            }

            // Check if Drill is Major-Mobe drill
            if ($drill->drill_type == 2) {
                $mobeDrill = Application_Model_MapMobeDrillForeman::Mapper()->getRecordByDrillForeman($drill->id, $rowForeman->id);
                if (sizeof($mobeDrill) > 0) {
                    $this->session->setSessVar('drillId', $drill->id, $randNo);
                    $otherDtls = array('rigId' => $mobeDrill[0]->rig_id, 'phaseId' => $mobeDrill[0]->phase_id, 'rigName' => $mobeDrill[0]->rig_name);
                    return $this->_forward('major-mobe-fisystem', 'fisystem', 'default', array('randNo' => $randNo,
                            'drill' => $drill, 'otherDtls' => $otherDtls, 'rowForeman' => $rowForeman, 'phaseId' => $otherDtls['phaseId'],
                            'reportDate' => $this->getRequest()->getParam('reportDate'), 'drillUpcoming' => $drillUpcoming));
                }
            }

            if ($drill->primary_foreman_id == $rowForeman->id || $drill->secondary_foreman_id == $rowForeman->id
                || $this->_identity->role_id == 1 || $this->_identity->role_id == 3):
                if ($drill->complete == null) {
                    $this->session->setSessVar('drillId', $this->getRequest()->getParam('id'), $randNo);
                } else {
                    // Check for Rig associative yard, Which will be displayed in FISystem
                    // Firstly get Rig from last completed drill
                    $objReport = Application_Model_ProgressReport::Mapper()->getForemanLastReport($drill->primary_foreman_id);

                    if (sizeof($objReport) > 0 && $this->_constants->key->showyard == 1) {
                        $useFisJs = false;
                        // Get associated yard details to show in FISystem
                        $objYard = Application_Model_Yard::Mapper()->getYardByRig($objReport[0]->rig_id);
                        return $this->_forward('yard-fisystem', 'fisystem', 'default', array('randNo' => $randNo, 'rigId' => $objReport[0]->rig_id, 'rigName' => $objReport[0]->rig_id,
                                'objYard' => $objYard, 'foremanId' => $drill->primary_foreman_id, 'phaseId' => $objReport[0]->phase_id,
                                'reportDate' => $this->getRequest()->getParam('reportDate')));
                    }
                }
            else:
                return $this->_forward('error', 'fisystem', 'default', array('from' => 'fisystem',
                        'header' => 'Access Denied', 'message' => 'You are not allowed to access this drill!', 'identity' => $this->_identity->role_id));
            endif;
        else:
            return $this->_forward('error', 'fisystem', 'default', array('from' => 'fisystem',
                    'header' => 'Access Denied', 'message' => "Your account is not registered as Foreman's account!", 'identity' => $this->_identity->role_id));
        endif;
    }

    /**
     * Method to check precedance should be given to which drill
     * Completed and further upcoming
     * 
     * @param object $rigs
     * @param object $jobs 
     */
    public function checkDrlPrecByForeman($drills, $foremanId)
    {
        $mobeRigMap = array();

        if (count($drills)) {
            $drillReports = array();
            $allJobs = array();
            foreach ($drills As $drillId) {
                $job = Application_Model_Drill::Mapper()->find($drillId);

                // Check which drill should be neglected by compairing progress report date
                if ($job->drill_type == 1) {
                    $drillReports['drill_' . $job->id] = strtotime($job->lastreportdate('onlyDate'));
                } else if ($job->drill_type == 2) {
                    $drillReports['drill_' . $job->id] = strtotime($job->lastreportdate('onlyDate', false, null, $foremanId));
                }
                $allJobs[] = $job;
                asort($drillReports);
            }

            $newDrillReports = $drillReports;
            end($newDrillReports);         // move the internal pointer to the end of the array
            $key = key($newDrillReports);

            $arrKey = explode('_', $key);
            $excludeDrills['exception'][] = array('rig_id' => $rig->id, 'drill_id' => $arrKey[1]);

            foreach ($allJobs As $rowJob) {
                if ($rowJob->id == $arrKey[1]) {
                    return array(0 => $rowJob);
                }
            }
        }
    }

    /**
     * Method to check precedance should be given to which drill
     * Completed and further upcoming
     * 
     * @param object $rigs
     * @param object $jobs 
     */
    public function checkDrillPrecedance($rigs, $jobs)
    {
        $mobeRigMap = array();
        foreach ($jobs as $job) {
            $rigMap = array();
            if ($job->drill_type == 2) {
                $mapRec = Application_Model_MapMobeDrillForeman::mapper()->getRecordByDrillForeman($job->id, null, null, false);

                if (sizeof($mapRec) > 0) {
                    foreach ($mapRec As $rowRec) {
                        $rigMap[] = $rowRec['rig_id'];
                    }
                }
                $mobeRigMap[] = array('drillId' => $job->id, 'rigMap' => $rigMap);
            }
        }

        $excludeDrills = array();
        foreach ($rigs as $rig) {
            $rigsDrills = array();
            foreach ($jobs as $job) {
                if ($job->drill_type == 1) {
                    if ($job->primary_rig_id == $rig->id) {
                        $rigsDrills[] = $job->id;
                    }
                } elseif ($job->drill_type == 2) {
                    if (sizeof($mobeRigMap) > 0) {
                        foreach ($mobeRigMap As $rowRigMap) {
                            if ($rowRigMap['drillId'] == $job->id) {
                                if (in_array($rig->id, $rowRigMap['rigMap'])) {
                                    $rigsDrills[] = $job->id;
                                }
                            }
                        }
                    }
                }
            }

            if (sizeof($rigsDrills) > 0) {
                $drillReports = array();
                foreach ($rigsDrills As $drillId) {
                    foreach ($jobs as $job) {
                        if ($job->id == $drillId) {
                            // Check which drill should be neglected by compairing progress report date
                            if ($job->drill_type == 1) {
                                $drillReports['drill_' . $job->id] = strtotime($job->lastreportdate('onlyDate'));
                            } else if ($job->drill_type == 2) {
                                $drillReports['drill_' . $job->id] = strtotime($job->lastreportdate('onlyDate', true, $rig->id));
                            }
                            asort($drillReports);
                        }
                    }
                }

                $newDrillReports = $drillReports;
                end($newDrillReports);         // move the internal pointer to the end of the array
                $key = key($newDrillReports);

                $arrKey = explode('_', $key);
                foreach ($jobs as $job) {
                    if ($job->id == $arrKey[1]) {
                        $excludeDrills['exception'][] = array('rig_id' => $rig->id, 'drill_id' => $arrKey[1],
                            'id' => $arrKey[1], 'drill_number' => $job->drill_number, 'drill_name' => $job->name, 'name' => $job->name);
                    }
                }

                array_pop($drillReports);

                foreach ($drillReports As $key => $val) {
                    $arrKey = explode('_', $key);
                    $excludeDrills['drills'][] = $arrKey[1];

                    foreach ($jobs as $job) {
                        if ($arrKey[1] == $job->id) {
                            $excludeDrills['drillsDtl'][] = array('id' => $arrKey[1], "rig_id" => $job->primary_rig_id,
                                'drill_name' => $job->name, 'drill_number' => $job->drill_number, 'name' => $job->name);
                        }
                    }
                }
            }
        }
        return $excludeDrills;
    }

    public function getForemanActiveDrills()
    {
        
    }

    /**
     * Method to get Upcoming cum current drill for Foreman
     * 
     * @author Mujaffar Sanadi      Created on 29 Aug 2014
     * @param int $foremanId 
     */
    public function getUpcomingCumCurrent($foremanId)
    {
        $drillRowset = $this->getWorkingRig($foremanId);

        $showYard = false;
        $drillUpcoming = array();

        if (count($drillRowset)) {
            // Check drill progress report count
            if ($drillRowset[0]->drill_type == 1) {
                $drillUpcoming = Application_Model_Drill::Mapper()->getDrillRepourtCount($drillRowset[0]->id);
            } else if ($drillRowset[0]->drill_type == 2) {
                $drillUpcoming = Application_Model_Drill::Mapper()->getDrillRepourtCount($drillRowset[0]->id, false, $drillRowset[1]['rigId']);
            }
            if ($drillUpcoming[0]->reportcount == 0 && $drillUpcoming[0]->target_start_date > date('Y-m-d')) {
                // This means the drill is still upcoming. In this case show Yard
                return null;
            } else {
                return array($drillRowset[0]->id);
            }
        } else {
            // This means the drill is still upcoming. In this case show Yard
            return null;
        }
    }

}