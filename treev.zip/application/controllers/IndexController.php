<?php

// Include session controller file to set and get session variables
require_once 'SessionController.php';

/**
 * Index controller class to handle landing page requests
 *
 * This class is designed for handling dashboard actions
 * 
 * @package    Default
 * @author     Unknown
 * @author     Last Modified By : Mujaffar Sanadi on 18 March 2013 [Modified index action to disply role specific view and created new action ajaxgetrigupdates]
 * @author     Last Modified By : Mujaffar Sanadi on 19 March 2013  [Created cronhandler action to take database backup]
 * @author     Last Modified By : Mujaffar Sanadi on 7 May 2013  [Created abbreviated action to display Rig abbreviated listing]
 * @author     Last Modified By : Mujaffar Sanadi on 14 May 2013  [Created rigphases action to display current active phase for Rig]
 * @author     Last Modified By : Mujaffar Sanadi on 14 May 2013  [Created public function getWeek to return week range by providing date]
 * @author     Last Modified By : Mujaffar Sanadi on 15 May 2013  [Created phaselookup action to  show Rig weekly phase details]
 * @author     Last Modified By : Mujaffar Sanadi on 06 June 2013  [Created ajaxgetrigdetails action to get Rig rigsection details from cache table]
 * @author     Last Modified By : Mujaffar Sanadi on 23 Aug 2013  [Created rigTracker action to display rigsection details from cache table]
 * @author     Last Modified By : Mujaffar Sanadi on 23 Aug 2013  [Created prontoForm For record interaction between third party ProntoForms]
 */
class IndexController extends Zend_Controller_Action
{

    /**
     * Init method to initialize variable
     * This methods runs prior executing any action to initialize variables
     * 
     * @author Unknown
     */
    public function init()
    {
        ////Zend_Session::destroy( true );
        /* Initialize action controller here */
        $this->_helper->_layout->setLayout('dashboard');
        $this->_helper->_layout->pageTitle = "";
        $this->_constants = Zend_Registry::get('constants');
    }

    public function indexAction()
    {
        $this->view->headScript()->appendFile('/js/comman_func.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/dom.jsPlumb-1.7.2-min.js?v=' . $this->_constants->key->jsversion);
        //$this->view->headScript()->appendFile('/js/main.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/md5.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/alche.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/jquery-ui-1.10.1.custom.min.js?v=' . $this->_constants->key->jsversion);
        //$this->view->headScript()->appendFile('/js/falld.js?v=' . $this->_constants->key->jsversion);
        $this->view->headLink()->appendStylesheet('/css/demo.css');
        $this->view->headLink()->appendStylesheet('/css/jsplumb.css');

        // Get all persons
        // $this->view->personList = Application_Model_Persons::mapper()->getAllRec();
    }
    
    public function invAction()
    {
        $this->view->headScript()->appendFile('/js/comman_func.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/dom.jsPlumb-1.7.2-min.js?v=' . $this->_constants->key->jsversion);
        //$this->view->headScript()->appendFile('/js/main.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/jquery-ui-1.10.1.custom.min.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/inv.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/phpjs.js?v=' . $this->_constants->key->jsversion);
        $this->view->headLink()->appendStylesheet('/css/demo.css');
        $this->view->headLink()->appendStylesheet('/css/jsplumb.css');

        // Get all persons
        // $this->view->personList = Application_Model_Persons::mapper()->getAllRec();
    }
    
    /**
     * Dashboard Index action to display Rig progress details in Rigsection tiles
     * 
     * @author Mujaffar Sanadi Modified on 18 March 2013 [Modified code to get results from cache table]
     */
    public function indexBkupAction()
    {
        $this->view->headScript()->appendFile('/js/comman_func.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/dom.jsPlumb-1.7.2-min.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/main.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/jquery-ui-1.10.1.custom.min.js?v=' . $this->_constants->key->jsversion);
        $this->view->headScript()->appendFile('/js/falld.js?v=' . $this->_constants->key->jsversion);
        $this->view->headLink()->appendStylesheet('/css/demo.css');
        $this->view->headLink()->appendStylesheet('/css/jsplumb.css');

        // Get all persons
        $this->view->personList = Application_Model_Persons::mapper()->getAllRec();
    }

    public function newmethodAction()
    {
        //$this->_helper->viewRenderer->setNoRender(true);


        echo "this is the new page";
    }

    public function gmailAction()
    {
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);

//        $mail = new Zend_Mail_Storage_Imap(array('host' => 'imap.gmail.com',
//            'user' => 'mujaffar.sanadi01@gmail.com',
//            'password' => ''));
//
//        echo $mail->countMessages() . " messages found\n";
//        foreach ($mail as $message) {
//            echo "Mail from '{$message->from}': {$message->subject}\n";
//        }

        /* header("Content-Type: text/plain; charset=UTF-8");
          mb_internal_encoding("UTF-8");

          function __autoload($sClassName)
          {
          $sLibFilePath = __DIR__ . '/' . str_replace('_', '/', $sClassName) . '.php';
          if (is_file($sLibFilePath)) {
          include_once($sLibFilePath);
          } else {
          return;
          }
          }

          $oImap = new Zend_Mail_Storage_Imap(
          array(
          'host' => 'imap.gmail.com',
          'port' => '993',
          'ssl' => true,
          'user' => 'mujaffar.sanadi01@gmail.com',
          'password' => '',
          )
          );
          $oImap->selectFolder('[Gmail]/Spam');
          echo $oImap->countMessages() . " messages found\n";
          foreach ($oImap as $iTempId => $oMessage) {
          $iUniqueId = $oImap->getUniqueId($iTempId);
          echo "[{$iTempId}/{$iUniqueId}] Mail from " . mb_decode_mimeheader($oMessage->from) . ": " . mb_decode_mimeheader($oMessage->subject) . "\n";
          if (rand(0, 5) == 0)
          break; //for testing
          } */

        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);

        /**
         * Builds an OAuth2 authentication string for the given email address and access
         * token.
         */
        function constructAuthString($email, $accessToken)
        {
            return base64_encode("user=$email\1auth=Bearer $accessToken\1\1");
        }

        /**
         * Given an open IMAP connection, attempts to authenticate with OAuth2.
         *
         * $imap is an open IMAP connection.
         * $email is a Gmail address.
         * $accessToken is a valid OAuth 2.0 access token for the given email address.
         *
         * Returns true on successful authentication, false otherwise.
         */
        function oauth2Authenticate($imap, $email, $accessToken)
        {
            $authenticateParams = array('XOAUTH2',
                constructAuthString($email, $accessToken));
            $imap->sendRequest('AUTHENTICATE', $authenticateParams);

            while (true) {
                $response = "";
                $is_plus = $imap->readLine($response, '+', true);
                if ($is_plus) {
                    error_log("got an extra server challenge: $response");
                    // Send empty client response.
                    $imap->sendRequest('');
                } else {
                    if (preg_match('/^NO /i', $response) ||
                        preg_match('/^BAD /i', $response)) {
                        error_log("got failure response: $response");

                        return false;
                    } else if (preg_match("/^OK /i", $response)) {
                        return true;
                    } else {
                        // Some untagged response, such as CAPABILITY
                    }
                }
            }
        }

        /**
         * Given an open and authenticated IMAP connection, displays some basic info
         * about the INBOX folder.
         */
        function showInbox($imap)
        {
            /**
             * Print the INBOX message count and the subject of all messages
             * in the INBOX
             */
            $storage = new Zend_Mail_Storage_Imap($imap);

            include 'header.php';
            echo '<h1>Total messages: ' . $storage->countMessages() . "</h1>\n";

            /**
             * Retrieve first 5 messages.  If retrieving more, you'll want
             * to directly use Zend_Mail_Protocol_Imap and do a batch retrieval,
             * plus retrieve only the headers
             */
            echo 'First five messages: <ul>';
            for ($i = 1; $i <= $storage->countMessages() && $i <= 5; $i++) {
                echo '<li>' . htmlentities($storage->getMessage($i)->subject) . "</li>\n";
            }
            echo '</ul>';
        }

        /**
         * Tries to login to IMAP and show inbox stats.
         */
        function tryImapLogin($email, $accessToken)
        {
            /**
             * Make the IMAP connection and send the auth request
             */
            $imap = new Zend_Mail_Protocol_Imap('imap.gmail.com', '993', true);
            if (oauth2Authenticate($imap, $email, $accessToken)) {
                echo '<h1>Successfully authenticated!</h1>';
                showInbox($imap);
            } else {
                echo '<h1>Failed to login</h1>';
            }
        }

        /**
         * Displays a form to collect the email address and access token.
         */
        function displayForm($email, $accessToken)
        {
            echo <<<END
<form method="POST" action="">
  <h1>Please enter your e-mail address: </h1>
  <input type="text" name="email" value="$email"/>
  <p>
  <h1>Please enter your access token: </h1>
  <input type="text" name="access_token" value="$accessToken"/>
  <input type="submit"/>
</form>
<hr>
END;
        }

        $email = $_POST['email'];
        $accessToken = $_POST['access_token'];

        displayForm($email, $accessToken);

        if ($email && $accessToken) {
            tryImapLogin($email, $accessToken);
        }
    }

    public function wappAction()
    {
        
    }

}
