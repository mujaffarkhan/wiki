<?php

/**
 * Class for Handling session in application
 *
 * This class is designed for handling session to set, get methods
 * 
 * @package    Default
 * @author     Mujaffar added on 13 Oct 2012
 */
class SessionController
{

    public static $session;
    protected static $_instance;

    /**
     * Constructor method runs when created boject for Session class
     * @param Zend_Controller_Request_Abstract $request
     * @param Zend_Controller_Response_Abstract $response
     * @param array $invokeArgs
     */
    public function __construct(Zend_Controller_Request_Abstract $request, Zend_Controller_Response_Abstract $response, array $invokeArgs = array())
    {
        
        //parent::__construct($request, $response, $invokeArgs);
        $this->session = new Zend_Session_Namespace('mysession');
        
        return $this->session;
    }

    /**
     * Method for Implementation of the singleton design pattern
     * @param $request
     * @param $response
     */
    public static function getInstance($request, $response)
    {
        if (null === self::$_instance) {
            self::$_instance = new self($request, $response);
        }
        return self::$_instance;
    }

    /**
     * Public method to retrieve a value stored in the session
     * return $default if $var not found in session namespace
     * @param $var string
     * @param $default string
     * @return string
     */
    public function getSessVar($var, $key, $default=null)
    {
        return (isset($this->session->$key->$var)) ? $this->session->$key->$var : $default;
    }

    /**
     * Public function to save a value to the session
     * @param $var string
     * @param $value
     */
    public function setSessVar($var, $value, $key=null)
    {
        if (!empty($var) && !empty($value)) {
            $this->session->$key->$var = $value;
        }
    }

    /**
     * Public function to destroy session
     */
    public function destroySession()
    {
        Zend_Session::destroy(true);
    }

    /**
     * Public function to destroy session
     */
    public function destroySessionField($var, $key=null)
    {
        $this->session->$key->$var = "";
    }

}

