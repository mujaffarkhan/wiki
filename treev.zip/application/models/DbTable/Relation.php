<?php

class Application_Model_DbTable_Relation extends Zend_Db_Table_Abstract
{

    protected $_name = 'relation';

}

