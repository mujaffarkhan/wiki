<?php

class Application_Model_DbTable_Wkwililinks extends Zend_Db_Table_Abstract
{

    protected $_name = 'wk_wikilinks';


}

