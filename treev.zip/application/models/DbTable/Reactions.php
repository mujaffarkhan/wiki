<?php

class Application_Model_DbTable_Reactions extends Zend_Db_Table_Abstract
{

    protected $_name = 'reactions';

}

