<?php

class Application_Model_DbTable_Wkinventor extends Zend_Db_Table_Abstract
{

    protected $_name = 'wk_inventor';


}

