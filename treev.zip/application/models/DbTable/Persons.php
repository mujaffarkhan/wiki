<?php

class Application_Model_DbTable_Persons extends Zend_Db_Table_Abstract
{

    protected $_name = 'persons';

}

