<?php

class Application_Model_DbTable_Wkera extends Zend_Db_Table_Abstract
{

    protected $_name = 'wk_era';


}

