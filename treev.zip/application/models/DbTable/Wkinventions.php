<?php

class Application_Model_DbTable_Wkinventions extends Zend_Db_Table_Abstract
{

    protected $_name = 'wk_inventions';


}

