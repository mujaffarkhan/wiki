<?php

class Application_Model_DbTable_Wkfacts extends Zend_Db_Table_Abstract
{

    protected $_name = 'wk_facts';


}

